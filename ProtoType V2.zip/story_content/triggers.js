function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xqy0TH0MoJ":
        Script1();
        break;
      case "6EzCkN688Aa":
        Script2();
        break;
      case "63kMJNGudiZ":
        Script3();
        break;
      case "61IQnCdOi4u":
        Script4();
        break;
      case "6fMs6LDWtke":
        Script5();
        break;
      case "60VDonqQX1I":
        Script6();
        break;
      case "6XqDYP20pZH":
        Script7();
        break;
      case "6LSDt4MiDtp":
        Script8();
        break;
      case "68O2vcXtmwM":
        Script9();
        break;
      case "6CQSVpEOeaC":
        Script10();
        break;
      case "5vN7dFJQDFi":
        Script11();
        break;
      case "61fL3IRPolv":
        Script12();
        break;
      case "6bOp8Bovxdv":
        Script13();
        break;
      case "6V3cRnupl5E":
        Script14();
        break;
      case "5wXkIYbYCOZ":
        Script15();
        break;
      case "6lvgu4rBqxS":
        Script16();
        break;
      case "6XTMkgnkGJV":
        Script17();
        break;
      case "5vzmgTlczlY":
        Script18();
        break;
      case "6g2uvNNKfSG":
        Script19();
        break;
      case "5XPNB8pKVAb":
        Script20();
        break;
      case "5ww4JZL3Mvk":
        Script21();
        break;
      case "67Z7mMU31LM":
        Script22();
        break;
      case "5v03hbP4TuN":
        Script23();
        break;
      case "5lzTIm5qUgr":
        Script24();
        break;
      case "6pf1jDZqhUG":
        Script25();
        break;
      case "6opJOkbkBu2":
        Script26();
        break;
      case "6dSDrIYwn47":
        Script27();
        break;
      case "5UntloiABzg":
        Script28();
        break;
      case "6p0Ffkbm5Mz":
        Script29();
        break;
      case "6iH5GMuwmK3":
        Script30();
        break;
      case "5pfBWpMb0x3":
        Script31();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
window.Script1 = function()
{
  const target = object('662Yov12Wq3');
const duration = 250;
const easing = 'ease-out';
const id = '5fWo8SYOAak';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('662Yov12Wq3');
const duration = 250;
const easing = 'ease-out';
const id = '5fWo8SYOAak_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('64H12B4kiCO');
const duration = 250;
const easing = 'ease-out';
const id = '6H7HVX1MaGX';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('64H12B4kiCO');
const duration = 250;
const easing = 'ease-out';
const id = '6H7HVX1MaGX_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6nH8fHIAwSS');
const duration = 250;
const easing = 'ease-out';
const id = '6o4j4deBogf';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('6nH8fHIAwSS');
const duration = 250;
const easing = 'ease-out';
const id = '6o4j4deBogf_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('5rjpczUopRj');
const duration = 250;
const easing = 'ease-out';
const id = '6S1LDLDonsD';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('5rjpczUopRj');
const duration = 250;
const easing = 'ease-out';
const id = '6S1LDLDonsD_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6EvthElpqOd');
const duration = 250;
const easing = 'ease-out';
const id = '6UVLCzXHYtJ';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('6EvthElpqOd');
const duration = 250;
const easing = 'ease-out';
const id = '6UVLCzXHYtJ_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('6HDEpYBjdaU');
const duration = 250;
const easing = 'ease-out';
const id = '5fWo8SYOAak';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('6HDEpYBjdaU');
const duration = 250;
const easing = 'ease-out';
const id = '5fWo8SYOAak_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('6OQu40wahqU');
const duration = 250;
const easing = 'ease-out';
const id = '6H7HVX1MaGX';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('6OQu40wahqU');
const duration = 250;
const easing = 'ease-out';
const id = '6H7HVX1MaGX_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  const target = object('6cRBE3hIu4u');
const duration = 250;
const easing = 'ease-out';
const id = '6o4j4deBogf';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  const target = object('6cRBE3hIu4u');
const duration = 250;
const easing = 'ease-out';
const id = '6o4j4deBogf_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  const target = object('5nxH0H568Q3');
const duration = 250;
const easing = 'ease-out';
const id = '6S1LDLDonsD';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script18 = function()
{
  const target = object('5nxH0H568Q3');
const duration = 250;
const easing = 'ease-out';
const id = '6S1LDLDonsD_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script19 = function()
{
  const target = object('6kNLxDWUiHB');
const duration = 250;
const easing = 'ease-out';
const id = '6UVLCzXHYtJ';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script20 = function()
{
  const target = object('6kNLxDWUiHB');
const duration = 250;
const easing = 'ease-out';
const id = '6UVLCzXHYtJ_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
