window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
window.Script21 = function()
{
  const obj_1 = object('5vSUVeGJdTP');
const obj_2 = object('6qwjenndJaX');
const obj_3 = object('5n56LfYzBR7');

const objs = [obj_1,obj_2,obj_3];

objs.forEach(obj=>obj.depth = 99199);


}

window.Script22 = function()
{
  const obj_1 = object('6YssrJf1aGO');
const obj_2 = object('6XlV5zT0Col');
const obj_3 = object('64WI0oEcQec');

const objs = [obj_1,obj_2,obj_3];

objs.forEach(obj=>obj.depth = 99299);


}

window.Script23 = function()
{
  const obj_1 = object('6kxOgza0lHO');
const obj_2 = object('6fdbWFQ5Jcf');
const obj_3 = object('5s6PIgI2VxK');

const objs = [obj_1,obj_2,obj_3];

objs.forEach(obj=>obj.depth = 99399);


}

window.Script24 = function()
{
  const obj_1 = object('5udwvFYb6ZM');
const obj_2 = object('6obcgZqasru');
const obj_3 = object('60dXK1WHoCb');

const objs = [obj_1,obj_2,obj_3];

objs.forEach(obj=>obj.depth = 99499);


}

window.Script25 = function()
{
  const obj_1 = object('6psdcsmXQfy');
const obj_2 = object('6IPjbeCIhnm');
const obj_3 = object('606tuApHSoJ');

const objs = [obj_1,obj_2,obj_3];

objs.forEach(obj=>obj.depth = 99599);


}

window.Script26 = function()
{
  const player = GetPlayer();
let coins2 = player.GetVar("golde_coins") / 10;
player.SetVar("score_2",coins2)
}

window.Script27 = function()
{
  const obj_1 = object('6lHNiehmKXv');
const obj_2 = object('6I7U47RQSEI');


const objs = [obj_1,obj_2];

objs.forEach(obj=>obj.depth = 99199);


}

window.Script28 = function()
{
  const obj_1 = object('5sRoR782WDv');
const obj_2 = object('6UA0HBlmqvA');


const objs = [obj_1,obj_2];

objs.forEach(obj=>obj.depth = 99299);


}

window.Script29 = function()
{
  const obj_1 = object('6HhmHPtoFGd');
const obj_2 = object('6GFoZu40GyH');

const objs = [obj_1,obj_2];

objs.forEach(obj=>obj.depth = 99399);


}

window.Script30 = function()
{
  const obj_1 = object('6BCCkTNogjm');
const obj_2 = object('6EyUAPfWNxA');

const objs = [obj_1,obj_2];

objs.forEach(obj=>obj.depth = 99499);


}

window.Script31 = function()
{
  const obj_1 = object('6Zn9emCbBQx');
const obj_2 = object('6HKYRGqC9E9');

const objs = [obj_1,obj_2];

objs.forEach(obj=>obj.depth = 99599);


}

};
